# ウサギと猟犬 (Hare and Hounds)

逃げるウサギと追いこむ猟犬の2人用非対称戦略ボードゲーム（完全情報・運要素なし）。  
『世界のアソビ大全51』にも収録されている名作古典ゲームを、AI対戦・ローカル2人対戦・Firebase Realtime Database通信対戦に対応したWebアプリとして実装しています。

## 🌟 特徴
- **完全再現された11頂点盤面 (A〜K)**
- **非対称ルール**:
  - 🐕 **猟犬（3匹・先手）**: 前進（右方向）または上下のみ。後退不可。ウサギの動けるマスを塞げば勝利。
  - 🐇 **ウサギ（1匹・後手）**: 全方向移動可能。猟犬3匹を突破して後方へ抜けるか、30ターン耐えれば勝利。
- **Minimax / α-β探索AI**（入門・実戦・神AIの3段階）
- **Framer Motionによる駒のスムーズなスライド移動アニメーション**
- **オンライン通信対戦**: Firebase Realtime Database (`rooms_br`) を利用した合言葉（部屋番号）マッチング
- **モバイル・PC完全レスポンシブ & Web Audio API効果音**

## 🚀 GitHub Pages への公開手順

### 1. リポジトリの準備
```bash
git init
git add .
git commit -m "Initial commit: Hare and Hounds game"
git branch -M main
git remote add origin https://github.com/<あなたのユーザー名>/<リポジトリ名>.git
git push -u origin main
```

### 2. GitHub Pages 自動デプロイ設定
1. GitHubリポジトリの **Settings** > **Pages** を開きます。
2. **Build and deployment** の **Source** で **「GitHub Actions」** を選択します。
3. リポジトリ内の `.github/workflows/deploy.yml` により、`main` にpushされると自動的にGitHub Pagesへ公開されます。

### 3. ローカル開発
```bash
npm install
npm run dev
```

### 4. ビルド
```bash
npm run build
```
