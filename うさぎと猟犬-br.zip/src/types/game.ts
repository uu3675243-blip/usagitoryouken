export type PieceType = 'hare' | 'hound';

export type PlayerRole = 'hound' | 'hare';

export type GameMode =
  | 'pve_hare'    // Human plays Hare, AI plays Hound
  | 'pve_hound'   // Human plays Hound, AI plays Hare
  | 'pvp'         // Local 2 Players Pass & Play
  | 'online'      // Realtime Online Match via Firebase rooms_br
  | 'eve';        // AI vs AI Demonstration

export type Difficulty = 'easy' | 'medium' | 'hard';

export type BoardSetup = 'standard' | 'line' | 'center_hare';

export interface BoardNode {
  id: number;          // 0 to 10
  name: string;        // 'A' to 'K'
  x: number;           // 0 to 4 (column index)
  y: number;           // 0 to 2 (row index)
  neighbors: number[]; // adjacent node IDs
}

export interface GameMove {
  player: PlayerRole;
  fromNode: number;
  toNode: number;
  houndIndex?: number;
  turnNumber: number;
  notation: string;
}

export type GameStatus = 'playing' | 'hare_won_escape' | 'hare_won_timeout' | 'hound_won_trapped';

export interface GameSettings {
  mode: GameMode;
  difficulty: Difficulty;
  boardSetup: BoardSetup;
  maxTurns: number;
  soundEnabled: boolean;
  showCoordinates: boolean;
}

export interface OnlineRoomData {
  roomId: string;
  createdAt: number;
  hounds: [number, number, number];
  hare: number;
  currentTurn: PlayerRole;
  turnCount: number;
  maxTurns: number;
  status: GameStatus;
  lastMove: { from: number; to: number; player: PlayerRole } | null;
  hostRole: PlayerRole;
  hostName: string;
  guestName?: string;
  playersCount: number;
}
