/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  GameMode,
  Difficulty,
  BoardSetup,
  PlayerRole,
  GameStatus,
  GameSettings,
  GameMove,
  OnlineRoomData,
} from './types/game';
import {
  BOARD_NODES,
  checkGameStatus,
  getInitialPositions,
  getLegalHareMoves,
  getLegalHoundMoves,
  isValidHareMove,
  isValidHoundMove,
  LegalHoundMove,
} from './engine/boardGraph';
import { getBestHareMove, getBestHoundMove } from './engine/ai';
import { soundManager } from './utils/audio';
import {
  createOnlineRoom,
  joinOnlineRoom,
  subscribeToRoom,
  updateOnlineMove,
  resetOnlineRoom,
} from './services/onlineService';
import { GameBoard } from './components/GameBoard';
import { GameHUD } from './components/GameHUD';
import { RulesModal } from './components/RulesModal';
import { SettingsModal } from './components/SettingsModal';
import { GameOverModal } from './components/GameOverModal';
import { MoveHistory } from './components/MoveHistory';
import { OnlineModal } from './components/OnlineModal';

interface BoardSnapshot {
  hounds: [number, number, number];
  hare: number;
  currentTurn: PlayerRole;
  turnCount: number;
  lastMove: { from: number; to: number; player: PlayerRole } | null;
}

export default function App() {
  // Settings
  const [settings, setSettings] = useState<GameSettings>({
    mode: 'pve_hare',
    difficulty: 'medium',
    boardSetup: 'standard',
    maxTurns: 30,
    soundEnabled: true,
    showCoordinates: true,
  });

  // Core Game State
  const [hounds, setHounds] = useState<[number, number, number]>(() =>
    getInitialPositions('standard').hounds
  );
  const [hare, setHare] = useState<number>(() =>
    getInitialPositions('standard').hare
  );
  const [currentTurn, setCurrentTurn] = useState<PlayerRole>('hound');
  const [turnCount, setTurnCount] = useState<number>(0);
  const [gameStatus, setGameStatus] = useState<GameStatus>('playing');
  const [moves, setMoves] = useState<GameMove[]>([]);

  // Online Multiplayer State
  const [onlineRoomId, setOnlineRoomId] = useState<string | null>(null);
  const [onlineMyRole, setOnlineMyRole] = useState<PlayerRole | null>(null);
  const [onlineRoom, setOnlineRoom] = useState<OnlineRoomData | null>(null);
  const [isOnlineModalOpen, setIsOnlineModalOpen] = useState(false);
  const [onlineError, setOnlineError] = useState<string | null>(null);
  const [isOnlineLoading, setIsOnlineLoading] = useState(false);

  // Selection & UI State
  const [selectedPiece, setSelectedPiece] = useState<{
    type: 'hare' | 'hound';
    index?: number;
    nodeId: number;
  } | null>(null);
  const [validDestinations, setValidDestinations] = useState<number[]>([]);
  const [lastMove, setLastMove] = useState<{
    from: number;
    to: number;
    player: PlayerRole;
  } | null>(null);
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);
  const [isEvePlaying, setIsEvePlaying] = useState<boolean>(true);

  // Modals & Notifications
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [showGameOverModal, setShowGameOverModal] = useState<boolean>(false);
  const [hintToast, setHintToast] = useState<string | null>(null);

  // Undo History Stack
  const historyStack = useRef<BoardSnapshot[]>([]);

  // Update sound manager
  useEffect(() => {
    soundManager.setEnabled(settings.soundEnabled);
  }, [settings.soundEnabled]);

  // Online Room Listener (Firebase Realtime Database)
  useEffect(() => {
    if (!onlineRoomId || settings.mode !== 'online') return;

    const unsubscribe = subscribeToRoom(onlineRoomId, (room) => {
      if (!room) {
        setOnlineError('部屋が切断されました。');
        return;
      }
      setOnlineRoom(room);
      setHounds(room.hounds);
      setHare(room.hare);
      setCurrentTurn(room.currentTurn);
      setTurnCount(room.turnCount);
      setGameStatus(room.status);
      setLastMove(room.lastMove);

      if (room.status !== 'playing') {
        setShowGameOverModal(true);
      }
    });

    return () => unsubscribe();
  }, [onlineRoomId, settings.mode]);

  // Restart / Initialize Game
  const resetGame = useCallback(
    (customSettings?: GameSettings) => {
      const activeSettings = customSettings || settings;

      if (activeSettings.mode === 'online' && onlineRoomId) {
        resetOnlineRoom(onlineRoomId).catch(() => {});
        return;
      }

      const initial = getInitialPositions(activeSettings.boardSetup);
      setHounds(initial.hounds);
      setHare(initial.hare);
      setCurrentTurn('hound');
      setTurnCount(0);
      setGameStatus('playing');
      setMoves([]);
      setSelectedPiece(null);
      setValidDestinations([]);
      setLastMove(null);
      setIsAiThinking(false);
      setShowGameOverModal(false);
      setHintToast(null);
      historyStack.current = [];
    },
    [settings, onlineRoomId]
  );

  // Online Actions: Create Room
  const handleCreateOnlineRoom = async (
    roomId: string,
    name: string,
    role: PlayerRole
  ) => {
    setIsOnlineLoading(true);
    setOnlineError(null);
    try {
      await createOnlineRoom(roomId, name, role);
      setOnlineRoomId(roomId);
      setOnlineMyRole(role);
      setSettings((prev) => ({ ...prev, mode: 'online' }));
      setIsOnlineModalOpen(false);
      setHintToast(`🎉 部屋「${roomId}」を作成しました！相手に番号を共有してください`);
      setTimeout(() => setHintToast(null), 5000);
    } catch (err) {
      setOnlineError('部屋の作成に失敗しました。接続環境をご確認ください。');
    } finally {
      setIsOnlineLoading(false);
    }
  };

  // Online Actions: Join Room
  const handleJoinOnlineRoom = async (roomId: string, name: string) => {
    setIsOnlineLoading(true);
    setOnlineError(null);
    try {
      const res = await joinOnlineRoom(roomId, name);
      if (!res.success || !res.role) {
        setOnlineError(res.error || '部屋に参加できませんでした。');
        return;
      }
      setOnlineRoomId(roomId);
      setOnlineMyRole(res.role);
      setSettings((prev) => ({ ...prev, mode: 'online' }));
      setIsOnlineModalOpen(false);
      setHintToast(`✨ 部屋「${roomId}」に参加しました！`);
      setTimeout(() => setHintToast(null), 4000);
    } catch (err) {
      setOnlineError('接続エラーが発生しました。');
    } finally {
      setIsOnlineLoading(false);
    }
  };

  // Leave Online Room
  const handleLeaveOnline = () => {
    setOnlineRoomId(null);
    setOnlineMyRole(null);
    setOnlineRoom(null);
    setSettings((prev) => ({ ...prev, mode: 'pve_hare' }));
    resetGame({ ...settings, mode: 'pve_hare' });
  };

  // Copy Room ID
  const handleCopyRoomId = () => {
    if (!onlineRoomId) return;
    navigator.clipboard?.writeText(onlineRoomId).catch(() => {});
    setHintToast(`📋 部屋番号「${onlineRoomId}」をコピーしました！`);
    setTimeout(() => setHintToast(null), 3000);
  };

  // Check if current turn is controlled by Human or AI
  const isHumanTurn = useCallback(() => {
    if (gameStatus !== 'playing') return false;
    if (isAiThinking) return false;

    if (settings.mode === 'online') {
      return onlineMyRole === currentTurn;
    }
    if (settings.mode === 'pvp') return true;
    if (settings.mode === 'eve') return false;
    if (settings.mode === 'pve_hare' && currentTurn === 'hare') return true;
    if (settings.mode === 'pve_hound' && currentTurn === 'hound') return true;
    return false;
  }, [gameStatus, isAiThinking, settings.mode, currentTurn, onlineMyRole]);

  // Execute a verified Move
  const executeMove = useCallback(
    (player: PlayerRole, from: number, to: number, houndIdx?: number) => {
      // Save snapshot for Undo before changing state
      historyStack.current.push({
        hounds: [...hounds] as [number, number, number],
        hare,
        currentTurn,
        turnCount,
        lastMove,
      });

      const nextTurnCount = turnCount + 1;
      let nextHounds: [number, number, number] = [...hounds];
      let nextHare = hare;

      if (player === 'hound' && houndIdx !== undefined) {
        nextHounds[houndIdx] = to;
        setHounds(nextHounds);
      } else if (player === 'hare') {
        nextHare = to;
        setHare(nextHare);
      }

      const fromName = BOARD_NODES[from].name;
      const toName = BOARD_NODES[to].name;
      const icon = player === 'hound' ? '🐕' : '🐇';
      const notation = `${icon} ${fromName} → ${toName}`;

      const newMoveRecord: GameMove = {
        player,
        fromNode: from,
        toNode: to,
        houndIndex: houndIdx,
        turnNumber: nextTurnCount,
        notation,
      };

      setMoves((prev) => [...prev, newMoveRecord]);
      const nextLastMove = { from, to, player };
      setLastMove(nextLastMove);
      setSelectedPiece(null);
      setValidDestinations([]);
      soundManager.playMove();

      const nextTurnRole: PlayerRole = player === 'hound' ? 'hare' : 'hound';

      // Check for Game Ending conditions
      const status = checkGameStatus(
        nextHare,
        nextHounds,
        nextTurnCount,
        settings.maxTurns,
        nextTurnRole
      );

      setTurnCount(nextTurnCount);
      setCurrentTurn(nextTurnRole);

      // If Online Mode, sync to Firebase RTDB (rooms_br)
      if (settings.mode === 'online' && onlineRoomId) {
        updateOnlineMove(
          onlineRoomId,
          nextHounds,
          nextHare,
          nextTurnRole,
          nextTurnCount,
          status,
          nextLastMove
        ).catch(() => {});
      }

      if (status !== 'playing') {
        setGameStatus(status);
        setShowGameOverModal(true);
        if (status === 'hound_won_trapped') {
          soundManager.playTrap();
        } else {
          soundManager.playWin();
        }
      }
    },
    [hounds, hare, currentTurn, turnCount, lastMove, settings.maxTurns, settings.mode, onlineRoomId]
  );

  // Handle Player Clicking a Node on the Board
  const handleSelectNode = useCallback(
    (nodeId: number) => {
      if (!isHumanTurn()) return;

      // 1. If playing as Hare:
      if (currentTurn === 'hare') {
        if (nodeId === hare) {
          if (selectedPiece?.type === 'hare') {
            setSelectedPiece(null);
            setValidDestinations([]);
          } else {
            setSelectedPiece({ type: 'hare', nodeId: hare });
            const dests = getLegalHareMoves(hare, hounds);
            setValidDestinations(dests);
            soundManager.playSelect();
          }
          return;
        }

        if (validDestinations.includes(nodeId)) {
          executeMove('hare', hare, nodeId);
          return;
        }

        if (isValidHareMove(hare, nodeId, hounds)) {
          executeMove('hare', hare, nodeId);
          return;
        }

        soundManager.playInvalid();
        return;
      }

      // 2. If playing as Hounds:
      if (currentTurn === 'hound') {
        const clickedHoundIdx = hounds.indexOf(nodeId);

        if (clickedHoundIdx !== -1) {
          if (selectedPiece?.type === 'hound' && selectedPiece.index === clickedHoundIdx) {
            setSelectedPiece(null);
            setValidDestinations([]);
          } else {
            setSelectedPiece({
              type: 'hound',
              index: clickedHoundIdx,
              nodeId,
            });
            const validMoves: number[] = [];
            BOARD_NODES[nodeId].neighbors.forEach((dest) => {
              if (isValidHoundMove(nodeId, dest, hare, hounds)) {
                validMoves.push(dest);
              }
            });
            setValidDestinations(validMoves);
            soundManager.playSelect();
          }
          return;
        }

        if (
          selectedPiece?.type === 'hound' &&
          selectedPiece.index !== undefined &&
          validDestinations.includes(nodeId)
        ) {
          executeMove('hound', selectedPiece.nodeId, nodeId, selectedPiece.index);
          return;
        }

        soundManager.playInvalid();
      }
    },
    [
      isHumanTurn,
      currentTurn,
      hare,
      hounds,
      selectedPiece,
      validDestinations,
      executeMove,
    ]
  );

  // Automatically select Hare when it is Hare's turn for quick movement
  useEffect(() => {
    if (isHumanTurn() && currentTurn === 'hare') {
      setSelectedPiece({ type: 'hare', nodeId: hare });
      const dests = getLegalHareMoves(hare, hounds);
      setValidDestinations(dests);
    }
  }, [currentTurn, hare, hounds, isHumanTurn]);

  // AI Turn Loop Trigger (Only in single-player or demo mode)
  useEffect(() => {
    if (gameStatus !== 'playing') return;
    if (settings.mode === 'online') return;

    const isAiTurn =
      (settings.mode === 'pve_hare' && currentTurn === 'hound') ||
      (settings.mode === 'pve_hound' && currentTurn === 'hare') ||
      (settings.mode === 'eve' && isEvePlaying);

    if (!isAiTurn || isAiThinking) return;

    setIsAiThinking(true);

    const delay = settings.mode === 'eve' ? 550 : 450;
    const timer = setTimeout(() => {
      if (currentTurn === 'hound') {
        const bestHoundMove: LegalHoundMove | null = getBestHoundMove(
          hounds,
          hare,
          turnCount,
          settings.maxTurns,
          settings.difficulty
        );
        if (bestHoundMove) {
          executeMove(
            'hound',
            bestHoundMove.from,
            bestHoundMove.to,
            bestHoundMove.houndIndex
          );
        } else {
          setGameStatus('hare_won_timeout');
          setShowGameOverModal(true);
        }
      } else if (currentTurn === 'hare') {
        const bestHareMove = getBestHareMove(
          hare,
          hounds,
          turnCount,
          settings.maxTurns,
          settings.difficulty
        );
        if (bestHareMove !== null) {
          executeMove('hare', hare, bestHareMove);
        } else {
          setGameStatus('hound_won_trapped');
          setShowGameOverModal(true);
        }
      }
      setIsAiThinking(false);
    }, delay);

    return () => clearTimeout(timer);
  }, [
    currentTurn,
    gameStatus,
    settings.mode,
    settings.difficulty,
    settings.maxTurns,
    hounds,
    hare,
    turnCount,
    isAiThinking,
    isEvePlaying,
    executeMove,
  ]);

  // Undo Functionality
  const handleUndo = useCallback(() => {
    if (historyStack.current.length === 0 || isAiThinking || settings.mode === 'online')
      return;

    let targetSnapshot: BoardSnapshot | undefined;

    if (settings.mode === 'pve_hare' || settings.mode === 'pve_hound') {
      if (historyStack.current.length >= 2) {
        historyStack.current.pop();
        targetSnapshot = historyStack.current.pop();
      } else {
        targetSnapshot = historyStack.current.pop();
      }
    } else {
      targetSnapshot = historyStack.current.pop();
    }

    if (targetSnapshot) {
      setHounds(targetSnapshot.hounds);
      setHare(targetSnapshot.hare);
      setCurrentTurn(targetSnapshot.currentTurn);
      setTurnCount(targetSnapshot.turnCount);
      setLastMove(targetSnapshot.lastMove);
      setGameStatus('playing');
      setShowGameOverModal(false);
      setSelectedPiece(null);
      setValidDestinations([]);
      setMoves((prev) => prev.slice(0, targetSnapshot!.turnCount));
      soundManager.playSelect();
    }
  }, [settings.mode, isAiThinking]);

  // Hint Functionality
  const handleGetHint = useCallback(() => {
    if (gameStatus !== 'playing' || isAiThinking) return;

    if (currentTurn === 'hound') {
      const bestMove = getBestHoundMove(
        hounds,
        hare,
        turnCount,
        settings.maxTurns,
        'hard'
      );
      if (bestMove) {
        const fromName = BOARD_NODES[bestMove.from].name;
        const toName = BOARD_NODES[bestMove.to].name;
        setSelectedPiece({
          type: 'hound',
          index: bestMove.houndIndex,
          nodeId: bestMove.from,
        });
        setValidDestinations([bestMove.to]);
        setHintToast(`💡 おすすめ手: 猟犬 ${bestMove.houndIndex + 1} (${fromName}) → ${toName}`);
        soundManager.playSelect();
      }
    } else {
      const bestHareNode = getBestHareMove(
        hare,
        hounds,
        turnCount,
        settings.maxTurns,
        'hard'
      );
      if (bestHareNode !== null) {
        const toName = BOARD_NODES[bestHareNode].name;
        setSelectedPiece({ type: 'hare', nodeId: hare });
        setValidDestinations([bestHareNode]);
        setHintToast(`💡 おすすめ手: ウサギ → ${toName}`);
        soundManager.playSelect();
      }
    }

    setTimeout(() => {
      setHintToast(null);
    }, 4000);
  }, [currentTurn, gameStatus, isAiThinking, hounds, hare, turnCount, settings.maxTurns]);

  // User Role for Game Over Screen
  const getUserRole = (): PlayerRole | 'both' => {
    if (settings.mode === 'online') {
      return onlineMyRole || 'both';
    }
    if (settings.mode === 'pve_hare') return 'hare';
    if (settings.mode === 'pve_hound') return 'hound';
    return 'both';
  };

  const opponentName =
    settings.mode === 'online' && onlineRoom
      ? onlineMyRole === onlineRoom.hostRole
        ? onlineRoom.guestName
        : onlineRoom.hostName
      : null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950 font-sans">
      {/* Top HUD and Navigation */}
      <GameHUD
        currentTurn={currentTurn}
        turnCount={turnCount}
        maxTurns={settings.maxTurns}
        mode={settings.mode}
        difficulty={settings.difficulty}
        isAiThinking={isAiThinking}
        canUndo={historyStack.current.length > 0 && settings.mode !== 'online'}
        soundEnabled={settings.soundEnabled}
        onlineRoomId={onlineRoomId}
        onlinePlayerRole={onlineMyRole}
        onlineOpponentName={opponentName}
        isOnlineConnected={Boolean(onlineRoom && onlineRoom.playersCount >= 2)}
        onUndo={handleUndo}
        onRestart={() => resetGame()}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenOnline={() => setIsOnlineModalOpen(true)}
        onLeaveOnline={handleLeaveOnline}
        onCopyRoomId={handleCopyRoomId}
        onToggleSound={() =>
          setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
        }
        onGetHint={handleGetHint}
      />

      {/* Hint Toast Banner */}
      {hintToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-40 bg-amber-400 text-slate-950 px-4 py-2 rounded-xl text-xs sm:text-sm font-black shadow-2xl flex items-center gap-2 animate-bounce">
          <span>{hintToast}</span>
        </div>
      )}

      {/* Main Board Arena */}
      <main className="flex-1 flex flex-col items-center justify-center p-2">
        <GameBoard
          hounds={hounds}
          hare={hare}
          currentTurn={currentTurn}
          selectedPiece={selectedPiece}
          validDestinations={validDestinations}
          isInteractive={isHumanTurn()}
          showCoordinates={settings.showCoordinates}
          lastMove={lastMove}
          onSelectNode={handleSelectNode}
        />
      </main>

      {/* Move History Drawer */}
      <MoveHistory moves={moves} />

      {/* Online Modal */}
      <OnlineModal
        isOpen={isOnlineModalOpen}
        onClose={() => setIsOnlineModalOpen(false)}
        onCreateRoom={handleCreateOnlineRoom}
        onJoinRoom={handleJoinOnlineRoom}
        error={onlineError}
        isLoading={isOnlineLoading}
      />

      {/* Rule Guide Modal */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onSave={(newSettings) => {
          setSettings(newSettings);
          resetGame(newSettings);
        }}
      />

      {/* Game Over Celebration Modal */}
      <GameOverModal
        status={gameStatus}
        turnCount={turnCount}
        maxTurns={settings.maxTurns}
        userRole={getUserRole()}
        onRestart={() => resetGame()}
        onReviewBoard={() => setShowGameOverModal(false)}
      />
    </div>
  );
}
