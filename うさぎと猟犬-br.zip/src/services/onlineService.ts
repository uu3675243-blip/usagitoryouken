import { ref, set, get, onValue, off, update } from 'firebase/database';
import { rtdb } from './firebase';
import { GameStatus, OnlineRoomData, PlayerRole } from '../types/game';
import { getInitialPositions } from '../engine/boardGraph';

export const ROOMS_ROOT = 'rooms_br';

export async function createOnlineRoom(
  roomId: string,
  hostName: string,
  hostRole: PlayerRole
): Promise<OnlineRoomData> {
  const initial = getInitialPositions('standard');
  const roomData: OnlineRoomData = {
    roomId,
    createdAt: Date.now(),
    hounds: initial.hounds,
    hare: initial.hare,
    currentTurn: 'hound',
    turnCount: 0,
    maxTurns: 30,
    status: 'playing',
    lastMove: null,
    hostRole,
    hostName: hostName.trim() || 'ホスト',
    playersCount: 1,
  };

  const roomRef = ref(rtdb, `${ROOMS_ROOT}/${roomId}`);
  await set(roomRef, roomData);
  return roomData;
}

export async function joinOnlineRoom(
  roomId: string,
  guestName: string
): Promise<{ success: boolean; role?: PlayerRole; error?: string; room?: OnlineRoomData }> {
  const roomRef = ref(rtdb, `${ROOMS_ROOT}/${roomId}`);
  const snapshot = await get(roomRef);

  if (!snapshot.exists()) {
    return { success: false, error: '部屋が見つかりません。部屋番号をご確認ください。' };
  }

  const room = snapshot.val() as OnlineRoomData;
  const guestRole: PlayerRole = room.hostRole === 'hound' ? 'hare' : 'hound';

  await update(roomRef, {
    guestName: guestName.trim() || 'ゲスト',
    playersCount: 2,
  });

  return { success: true, role: guestRole, room };
}

export function subscribeToRoom(
  roomId: string,
  callback: (room: OnlineRoomData | null) => void
) {
  const roomRef = ref(rtdb, `${ROOMS_ROOT}/${roomId}`);
  onValue(roomRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.val() as OnlineRoomData);
    } else {
      callback(null);
    }
  });

  return () => {
    off(roomRef);
  };
}

export async function updateOnlineMove(
  roomId: string,
  hounds: [number, number, number],
  hare: number,
  currentTurn: PlayerRole,
  turnCount: number,
  status: GameStatus,
  lastMove: { from: number; to: number; player: PlayerRole }
) {
  const roomRef = ref(rtdb, `${ROOMS_ROOT}/${roomId}`);
  await update(roomRef, {
    hounds,
    hare,
    currentTurn,
    turnCount,
    status,
    lastMove,
  });
}

export async function resetOnlineRoom(roomId: string) {
  const initial = getInitialPositions('standard');
  const roomRef = ref(rtdb, `${ROOMS_ROOT}/${roomId}`);
  await update(roomRef, {
    hounds: initial.hounds,
    hare: initial.hare,
    currentTurn: 'hound',
    turnCount: 0,
    status: 'playing',
    lastMove: null,
  });
}
