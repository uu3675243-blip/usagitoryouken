import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

export const firebaseConfig = {
  apiKey: "AIzaSyDTH8N9_9QAj_Id9KNnvVfN62v42zg-Rtk",
  authDomain: "hiragajan-af30f.firebaseapp.com",
  databaseURL: "https://hiragajan-af30f-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "hiragajan-af30f",
  storageBucket: "hiragajan-af30f.firebasestorage.app",
  messagingSenderId: "209578576362",
  appId: "1:209578576362:web:1875a3f7ce9ff21c93ca93"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const rtdb = getDatabase(app);
