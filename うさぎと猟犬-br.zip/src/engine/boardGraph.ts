import { BoardNode, BoardSetup, GameStatus, PlayerRole } from '../types/game';

export const BOARD_NODES: BoardNode[] = [
  { id: 0, name: 'A', x: 0, y: 1, neighbors: [1, 2, 3] },
  { id: 1, name: 'B', x: 1, y: 0, neighbors: [0, 2, 4, 5] },
  { id: 2, name: 'C', x: 1, y: 1, neighbors: [0, 1, 3, 4, 5, 6] },
  { id: 3, name: 'D', x: 1, y: 2, neighbors: [0, 2, 5, 6] },
  { id: 4, name: 'E', x: 2, y: 0, neighbors: [1, 2, 5, 7, 8] },
  { id: 5, name: 'F', x: 2, y: 1, neighbors: [1, 2, 3, 4, 6, 7, 8, 9] },
  { id: 6, name: 'G', x: 2, y: 2, neighbors: [2, 3, 5, 8, 9] },
  { id: 7, name: 'H', x: 3, y: 0, neighbors: [4, 5, 8, 10] },
  { id: 8, name: 'I', x: 3, y: 1, neighbors: [4, 5, 6, 7, 9, 10] },
  { id: 9, name: 'J', x: 3, y: 2, neighbors: [5, 6, 8, 10] },
  { id: 10, name: 'K', x: 4, y: 1, neighbors: [7, 8, 9] },
];

export const EDGES: [number, number][] = [
  [0, 1], [0, 2], [0, 3],
  [1, 2], [1, 4], [1, 5],
  [2, 3], [2, 4], [2, 5], [2, 6],
  [3, 5], [3, 6],
  [4, 5], [4, 7], [4, 8],
  [5, 6], [5, 7], [5, 8], [5, 9],
  [6, 8], [6, 9],
  [7, 8], [7, 10],
  [8, 9], [8, 10],
  [9, 10]
];

export function getNode(id: number): BoardNode {
  return BOARD_NODES[id];
}

export function getInitialPositions(setup: BoardSetup): { hounds: [number, number, number]; hare: number } {
  switch (setup) {
    case 'line':
      // Hounds in Col 1: B (1), C (2), D (3); Hare at K (10)
      return { hounds: [1, 2, 3], hare: 10 };
    case 'center_hare':
      // Hounds at A (0), B (1), D (3); Hare in center F (5)
      return { hounds: [0, 1, 3], hare: 5 };
    case 'standard':
    default:
      // Standard official: Hounds at A (0), B (1), D (3); Hare at K (10)
      return { hounds: [0, 1, 3], hare: 10 };
  }
}

/**
 * Checks if target node is an allowable move for Hare
 */
export function isValidHareMove(from: number, to: number, hounds: [number, number, number]): boolean {
  if (hounds.includes(to)) return false;
  return BOARD_NODES[from].neighbors.includes(to);
}

/**
 * Returns all valid destination node IDs for Hare
 */
export function getLegalHareMoves(hare: number, hounds: [number, number, number]): number[] {
  const node = BOARD_NODES[hare];
  return node.neighbors.filter((neighbor) => !hounds.includes(neighbor));
}

/**
 * Checks if target node is an allowable move for a Hound
 * (Must be adjacent, unoccupied, and not backwards: toNode.x >= fromNode.x)
 */
export function isValidHoundMove(
  from: number,
  to: number,
  hare: number,
  hounds: [number, number, number]
): boolean {
  if (to === hare) return false;
  if (hounds.includes(to)) return false;
  if (!BOARD_NODES[from].neighbors.includes(to)) return false;
  // Hound cannot move backwards (x cannot decrease)
  return BOARD_NODES[to].x >= BOARD_NODES[from].x;
}

export interface LegalHoundMove {
  houndIndex: number;
  from: number;
  to: number;
}

/**
 * Returns all legal moves for all three hounds
 */
export function getLegalHoundMoves(
  hounds: [number, number, number],
  hare: number
): LegalHoundMove[] {
  const moves: LegalHoundMove[] = [];
  hounds.forEach((from, houndIndex) => {
    const fromNode = BOARD_NODES[from];
    fromNode.neighbors.forEach((to) => {
      if (isValidHoundMove(from, to, hare, hounds)) {
        moves.push({ houndIndex, from, to });
      }
    });
  });
  return moves;
}

/**
 * Check if the game has concluded
 */
export function checkGameStatus(
  hare: number,
  hounds: [number, number, number],
  turnCount: number,
  maxTurns: number,
  currentTurn: PlayerRole
): GameStatus {
  const hareX = BOARD_NODES[hare].x;
  const minHoundX = Math.min(
    BOARD_NODES[hounds[0]].x,
    BOARD_NODES[hounds[1]].x,
    BOARD_NODES[hounds[2]].x
  );

  // 1. Hare Escaped: Hare is to the left of all 3 hounds
  // Since hounds cannot move backwards, hare can never be caught
  if (hareX < minHoundX) {
    return 'hare_won_escape';
  }

  // 2. Timeout / Endurance limit reached
  if (turnCount >= maxTurns) {
    return 'hare_won_timeout';
  }

  // 3. Trapped: If it's Hare's turn and Hare has no moves left
  if (currentTurn === 'hare') {
    const legalMoves = getLegalHareMoves(hare, hounds);
    if (legalMoves.length === 0) {
      return 'hound_won_trapped';
    }
  }

  return 'playing';
}
