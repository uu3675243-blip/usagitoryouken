import { Difficulty, PlayerRole } from '../types/game';
import {
  BOARD_NODES,
  checkGameStatus,
  getLegalHareMoves,
  getLegalHoundMoves,
  LegalHoundMove,
} from './boardGraph';

/**
 * Normalizes hounds state (sorted node IDs) for transposition table caching
 */
function stateKey(
  hounds: [number, number, number],
  hare: number,
  turn: PlayerRole
): string {
  const sorted = [...hounds].sort((a, b) => a - b);
  return `${sorted.join(',')}:${hare}:${turn}`;
}

/**
 * Static heuristic board evaluation (positive favors Hare, negative favors Hounds)
 */
function evaluatePosition(
  hounds: [number, number, number],
  hare: number,
  turnCount: number,
  maxTurns: number
): number {
  const hareNode = BOARD_NODES[hare];
  const houndNodes = hounds.map((h) => BOARD_NODES[h]);
  const minHoundX = Math.min(...houndNodes.map((n) => n.x));
  const maxHoundX = Math.max(...houndNodes.map((n) => n.x));

  // Escape condition: Hare passed all hounds
  if (hareNode.x < minHoundX) {
    return 10000 - turnCount;
  }

  // Hare mobility (number of legal moves)
  const hareMobility = getLegalHareMoves(hare, hounds).length;
  if (hareMobility === 0) {
    return -10000 + turnCount;
  }

  // Turn endurance progress
  const turnBonus = (turnCount / maxTurns) * 300;

  // Hare distance to escape (smaller x is better for hare)
  // Distance from hare to left edge
  const hareEscapeDrive = (4 - hareNode.x) * 150;

  // Hound formation coherence: penalize when hounds are spread out across many columns
  const houndSpreadPenalty = (maxHoundX - minHoundX) * 40;

  // Average distance from hounds to hare (Manhattan / graph distance)
  let totalDist = 0;
  houndNodes.forEach((hn) => {
    totalDist += Math.abs(hn.x - hareNode.x) + Math.abs(hn.y - hareNode.y);
  });

  // Hounds want to reduce total distance and trap the hare
  const houndClosenessScore = totalDist * 35;

  return hareEscapeDrive + hareMobility * 80 + turnBonus + houndSpreadPenalty - houndClosenessScore;
}

/**
 * Minimax with Alpha-Beta Pruning and Transposition Table
 */
function minimax(
  hounds: [number, number, number],
  hare: number,
  turn: PlayerRole,
  depth: number,
  alpha: number,
  beta: number,
  turnCount: number,
  maxTurns: number,
  memo: Map<string, number>
): number {
  const key = stateKey(hounds, hare, turn);
  if (memo.has(key)) {
    return memo.get(key)!;
  }

  const status = checkGameStatus(hare, hounds, turnCount, maxTurns, turn);
  if (status === 'hare_won_escape' || status === 'hare_won_timeout') {
    return 10000 - turnCount;
  }
  if (status === 'hound_won_trapped') {
    return -10000 + turnCount;
  }

  if (depth === 0) {
    const val = evaluatePosition(hounds, hare, turnCount, maxTurns);
    memo.set(key, val);
    return val;
  }

  if (turn === 'hare') {
    // Maximizing player
    let maxEval = -Infinity;
    const legalMoves = getLegalHareMoves(hare, hounds);
    if (legalMoves.length === 0) {
      return -10000 + turnCount;
    }

    // Sort moves to check promising ones first (moving leftwards)
    legalMoves.sort((a, b) => BOARD_NODES[a].x - BOARD_NODES[b].x);

    for (const nextHare of legalMoves) {
      const evaluation = minimax(
        hounds,
        nextHare,
        'hound',
        depth - 1,
        alpha,
        beta,
        turnCount + 1,
        maxTurns,
        memo
      );
      maxEval = Math.max(maxEval, evaluation);
      alpha = Math.max(alpha, evaluation);
      if (beta <= alpha) break;
    }
    memo.set(key, maxEval);
    return maxEval;
  } else {
    // Minimizing player (Hounds)
    let minEval = Infinity;
    const legalMoves = getLegalHoundMoves(hounds, hare);
    if (legalMoves.length === 0) {
      // Hounds have no moves (stalemate, hare wins)
      return 10000 - turnCount;
    }

    // Sort moves: hounds moving rightwards or closing distance first
    legalMoves.sort((a, b) => BOARD_NODES[b.to].x - BOARD_NODES[a.to].x);

    for (const move of legalMoves) {
      const nextHounds: [number, number, number] = [...hounds];
      nextHounds[move.houndIndex] = move.to;

      const evaluation = minimax(
        nextHounds,
        hare,
        'hare',
        depth - 1,
        alpha,
        beta,
        turnCount + 1,
        maxTurns,
        memo
      );
      minEval = Math.min(minEval, evaluation);
      beta = Math.min(beta, evaluation);
      if (beta <= alpha) break;
    }
    memo.set(key, minEval);
    return minEval;
  }
}

/**
 * Select best move for Hounds
 */
export function getBestHoundMove(
  hounds: [number, number, number],
  hare: number,
  turnCount: number,
  maxTurns: number,
  difficulty: Difficulty
): LegalHoundMove | null {
  const legalMoves = getLegalHoundMoves(hounds, hare);
  if (legalMoves.length === 0) return null;

  // Easy mode: 45% chance of random move, otherwise shallow eval
  if (difficulty === 'easy' && Math.random() < 0.45) {
    return legalMoves[Math.floor(Math.random() * legalMoves.length)];
  }

  const depth = difficulty === 'hard' ? 8 : difficulty === 'medium' ? 4 : 2;
  const memo = new Map<string, number>();

  let bestMove: LegalHoundMove = legalMoves[0];
  let minScore = Infinity;

  // Shuffle slightly to avoid mechanical repetition when scores are tied
  const shuffledMoves = [...legalMoves].sort(() => Math.random() - 0.5);

  for (const move of shuffledMoves) {
    const nextHounds: [number, number, number] = [...hounds];
    nextHounds[move.houndIndex] = move.to;

    const score = minimax(
      nextHounds,
      hare,
      'hare',
      depth - 1,
      -Infinity,
      Infinity,
      turnCount + 1,
      maxTurns,
      memo
    );

    if (score < minScore) {
      minScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}

/**
 * Select best move for Hare
 */
export function getBestHareMove(
  hare: number,
  hounds: [number, number, number],
  turnCount: number,
  maxTurns: number,
  difficulty: Difficulty
): number | null {
  const legalMoves = getLegalHareMoves(hare, hounds);
  if (legalMoves.length === 0) return null;

  // Easy mode: 40% chance of random choice
  if (difficulty === 'easy' && Math.random() < 0.4) {
    return legalMoves[Math.floor(Math.random() * legalMoves.length)];
  }

  const depth = difficulty === 'hard' ? 8 : difficulty === 'medium' ? 4 : 2;
  const memo = new Map<string, number>();

  let bestMove = legalMoves[0];
  let maxScore = -Infinity;

  const shuffledMoves = [...legalMoves].sort(() => Math.random() - 0.5);

  for (const nextHare of shuffledMoves) {
    const score = minimax(
      hounds,
      nextHare,
      'hound',
      depth - 1,
      -Infinity,
      Infinity,
      turnCount + 1,
      maxTurns,
      memo
    );

    if (score > maxScore) {
      maxScore = score;
      bestMove = nextHare;
    }
  }

  return bestMove;
}
