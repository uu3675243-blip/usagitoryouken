import React, { useState } from 'react';
import { X, Globe, Copy, Check, Users } from 'lucide-react';
import { PlayerRole } from '../types/game';

interface OnlineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateRoom: (roomId: string, name: string, role: PlayerRole) => void;
  onJoinRoom: (roomId: string, name: string) => void;
  error?: string | null;
  isLoading?: boolean;
}

export const OnlineModal: React.FC<OnlineModalProps> = ({
  isOpen,
  onClose,
  onCreateRoom,
  onJoinRoom,
  error,
  isLoading,
}) => {
  const [tab, setTab] = useState<'create' | 'join'>('create');
  const [name, setName] = useState('プレイヤー');
  const [role, setRole] = useState<PlayerRole>('hound');
  const [joinRoomId, setJoinRoomId] = useState('');
  const [copied, setCopied] = useState(false);
  const [createdRoomId] = useState(() =>
    Math.random().toString(36).substring(2, 8).toUpperCase()
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-3xl shadow-2xl p-4 sm:p-6 text-slate-200 space-y-4 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <Globe size={20} />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">オンライン通信対局</h2>
              <p className="text-xs text-slate-400">Firebase Realtime DB (rooms_br) 連携</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => setTab('create')}
            className={`py-2 rounded-lg transition ${
              tab === 'create'
                ? 'bg-amber-400 text-slate-950 shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            部屋を作成する (ホスト)
          </button>
          <button
            type="button"
            onClick={() => setTab('join')}
            className={`py-2 rounded-lg transition ${
              tab === 'join'
                ? 'bg-amber-400 text-slate-950 shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            部屋に参加する (ゲスト)
          </button>
        </div>

        {/* Name Input */}
        <div>
          <label className="block text-xs font-bold text-slate-300 mb-1">あなたのお名前</label>
          <input
            type="text"
            maxLength={10}
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-amber-400"
            placeholder="例: たろう"
          />
        </div>

        {tab === 'create' ? (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                生成された部屋番号
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={createdRoomId}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-mono font-black text-sm tracking-widest text-center"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(createdRoomId);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition shrink-0"
                  title="部屋番号をコピー"
                >
                  {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                  <span>{copied ? '済' : 'コピー'}</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                あなたの担当
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRole('hound')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    role === 'hound'
                      ? 'bg-amber-950/40 border-amber-500 text-amber-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-sm">🐕 猟犬 (Hounds)</div>
                  <div className="text-[10px] text-slate-400">先手・3匹・追撃</div>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('hare')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    role === 'hare'
                      ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-sm">🐇 ウサギ (Hare)</div>
                  <div className="text-[10px] text-slate-400">後手・1匹・逃走</div>
                </button>
              </div>
            </div>

            {error && <div className="text-rose-400 text-xs font-bold">{error}</div>}

            <button
              type="button"
              disabled={isLoading}
              onClick={() => onCreateRoom(createdRoomId, name, role)}
              className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-sm shadow transition disabled:opacity-50"
            >
              {isLoading ? '部屋を作成中...' : '部屋を作成して待機'}
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                対戦相手から教えてもらった部屋番号
              </label>
              <input
                type="text"
                maxLength={6}
                value={joinRoomId}
                onChange={(e) => setJoinRoomId(e.target.value.toUpperCase())}
                placeholder="6桁の部屋番号 (例: ABC123)"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-amber-400 font-mono font-black text-sm tracking-widest text-center uppercase focus:outline-none focus:border-amber-400"
              />
            </div>

            {error && <div className="text-rose-400 text-xs font-bold">{error}</div>}

            <button
              type="button"
              disabled={isLoading || !joinRoomId.trim()}
              onClick={() => onJoinRoom(joinRoomId.trim(), name)}
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-sm shadow transition disabled:opacity-50"
            >
              {isLoading ? '接続中...' : 'この部屋に参加する'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
