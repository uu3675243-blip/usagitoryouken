import React from 'react';
import { GameMove } from '../types/game';
import { History, ChevronDown, ChevronUp } from 'lucide-react';

interface MoveHistoryProps {
  moves: GameMove[];
}

export const MoveHistory: React.FC<MoveHistoryProps> = ({ moves }) => {
  const [isExpanded, setIsExpanded] = React.useState(false);

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-4 pb-4">
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow">
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full px-4 py-2.5 flex items-center justify-between text-xs font-bold text-slate-400 hover:text-slate-200 transition"
        >
          <div className="flex items-center gap-2">
            <History size={14} className="text-amber-400" />
            <span>棋譜・着手履歴 ({moves.length} 手)</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-slate-500">
            {moves.length > 0 && (
              <span className="hidden sm:inline font-mono">
                直近: {moves[moves.length - 1].notation}
              </span>
            )}
            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </button>

        {isExpanded && (
          <div className="p-3 border-t border-slate-800 bg-slate-950/60 max-h-48 overflow-y-auto">
            {moves.length === 0 ? (
              <div className="text-center text-xs text-slate-500 py-3">
                まだ着手はありません。猟犬からスタートします。
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                {moves.map((move, idx) => (
                  <div
                    key={`move-${idx}`}
                    className={`flex items-center justify-between px-2.5 py-1 rounded-lg border text-[11px] ${
                      move.player === 'hound'
                        ? 'bg-amber-950/20 border-amber-900/40 text-amber-300'
                        : 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300'
                    }`}
                  >
                    <span className="text-slate-500 font-bold">{move.turnNumber}.</span>
                    <span className="font-semibold">{move.notation}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
