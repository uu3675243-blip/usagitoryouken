import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { BOARD_NODES, EDGES } from '../engine/boardGraph';
import { PlayerRole } from '../types/game';

interface GameBoardProps {
  hounds: [number, number, number];
  hare: number;
  currentTurn: PlayerRole;
  selectedPiece: { type: 'hare' | 'hound'; index?: number; nodeId: number } | null;
  validDestinations: number[];
  isInteractive: boolean;
  showCoordinates: boolean;
  lastMove: { from: number; to: number; player: PlayerRole } | null;
  onSelectNode: (nodeId: number) => void;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  hounds,
  hare,
  currentTurn,
  selectedPiece,
  validDestinations,
  isInteractive,
  showCoordinates,
  lastMove,
  onSelectNode,
}) => {
  // SVG coordinates for the 11 nodes
  const nodePositions = useMemo(() => {
    return BOARD_NODES.map((node) => {
      let cx = 400;
      let cy = 230;

      if (node.x === 0) cx = 95;
      else if (node.x === 1) cx = 250;
      else if (node.x === 2) cx = 400;
      else if (node.x === 3) cx = 550;
      else if (node.x === 4) cx = 705;

      if (node.y === 0) cy = 75;
      else if (node.y === 1) cy = 230;
      else if (node.y === 2) cy = 385;

      return { ...node, cx, cy };
    });
  }, []);

  return (
    <div className="relative w-full max-w-4xl mx-auto flex items-center justify-center p-2 sm:p-4 select-none">
      {/* Board Container with subtle board frame */}
      <div className="w-full relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800 shadow-2xl p-2 sm:p-5 overflow-hidden">
        
        {/* Subtle decorative background watermarks and hound direction hint */}
        <div className="absolute top-3 left-4 flex items-center gap-2 text-xs font-semibold text-slate-500 tracking-wider">
          <span>🐕 猟犬の進行方向</span>
          <span className="text-amber-400 font-bold tracking-widest text-sm">→ → →</span>
          <span className="text-[11px] text-slate-600 hidden sm:inline">(後退不可)</span>
        </div>

        <div className="absolute top-3 right-4 flex items-center gap-2 text-xs font-semibold text-slate-500 tracking-wider">
          <span>🐇 ウサギ</span>
          <span className="text-emerald-400 font-bold text-[11px]">全方向移動可</span>
        </div>

        {/* SVG Board */}
        <svg
          viewBox="0 0 800 460"
          className="w-full h-auto drop-shadow-lg touch-manipulation"
          style={{ maxHeight: '68vh' }}
        >
          <defs>
            {/* Soft board background gradient */}
            <linearGradient id="boardGlow" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#0f172a" stopOpacity="0.8" />
            </linearGradient>

            {/* Hound piece gradient */}
            <linearGradient id="houndGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>

            {/* Hare piece gradient */}
            <linearGradient id="hareGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>

            {/* Glow filters */}
            <filter id="glowGold" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glowGreen" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Board Connective Lines (Edges) */}
          <g className="edges">
            {EDGES.map(([u, v], idx) => {
              const from = nodePositions[u];
              const to = nodePositions[v];
              const isLastMovePath =
                lastMove &&
                ((lastMove.from === u && lastMove.to === v) ||
                  (lastMove.from === v && lastMove.to === u));

              return (
                <g key={`edge-${idx}`}>
                  {/* Outer edge glow for last move */}
                  {isLastMovePath && (
                    <line
                      x1={from.cx}
                      y1={from.cy}
                      x2={to.cx}
                      y2={to.cy}
                      stroke="#f59e0b"
                      strokeWidth="8"
                      strokeOpacity="0.3"
                      strokeLinecap="round"
                    />
                  )}
                  {/* Core line */}
                  <line
                    x1={from.cx}
                    y1={from.cy}
                    x2={to.cx}
                    y2={to.cy}
                    stroke={isLastMovePath ? '#f59e0b' : '#334155'}
                    strokeWidth={isLastMovePath ? '4' : '3'}
                    strokeLinecap="round"
                    className="transition-colors duration-300"
                  />
                </g>
              );
            })}
          </g>

          {/* Board Nodes (Vertices) */}
          <g className="nodes">
            {nodePositions.map((node) => {
              const isHound = hounds.includes(node.id);
              const isHare = hare === node.id;
              const isSelected = selectedPiece?.nodeId === node.id;
              const isValidDest = validDestinations.includes(node.id);

              return (
                <g
                  key={`node-${node.id}`}
                  className={`cursor-pointer transition-transform duration-200 ${
                    isValidDest ? 'animate-pulse' : ''
                  }`}
                  onClick={() => isInteractive && onSelectNode(node.id)}
                >
                  {/* Invisible enlarged hit target for easy mobile touching */}
                  <circle cx={node.cx} cy={node.cy} r="36" fill="transparent" />

                  {/* Valid destination halo */}
                  {isValidDest && (
                    <circle
                      cx={node.cx}
                      cy={node.cy}
                      r="28"
                      fill="none"
                      stroke={currentTurn === 'hare' ? '#10b981' : '#f59e0b'}
                      strokeWidth="3"
                      strokeDasharray="6 4"
                      className="animate-spin"
                      style={{ transformOrigin: `${node.cx}px ${node.cy}px` }}
                    />
                  )}

                  {/* Base node ring */}
                  <circle
                    cx={node.cx}
                    cy={node.cy}
                    r={isSelected ? '22' : '18'}
                    fill={isValidDest ? '#0f172a' : '#1e293b'}
                    stroke={
                      isSelected
                        ? currentTurn === 'hare'
                          ? '#10b981'
                          : '#f59e0b'
                        : isValidDest
                        ? currentTurn === 'hare'
                          ? '#34d399'
                          : '#fbbf24'
                        : '#475569'
                    }
                    strokeWidth={isSelected || isValidDest ? '3' : '2'}
                    className="transition-all duration-200"
                  />

                  {/* Coordinate Label */}
                  {showCoordinates && !isHound && !isHare && (
                    <text
                      x={node.cx}
                      y={node.cy + 4}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fill="#94a3b8"
                      fontSize="12"
                      fontWeight="bold"
                      className="pointer-events-none select-none"
                    >
                      {node.name}
                    </text>
                  )}

                  {/* Destination indicator dot when empty */}
                  {isValidDest && !isHound && !isHare && (
                    <circle
                      cx={node.cx}
                      cy={node.cy}
                      r="7"
                      fill={currentTurn === 'hare' ? '#10b981' : '#f59e0b'}
                    />
                  )}
                </g>
              );
            })}
          </g>

          {/* Pieces Layer */}
          <g className="pieces">
            {/* Hounds */}
            {hounds.map((nodeId, idx) => {
              const node = nodePositions[nodeId];
              const isSelected = selectedPiece?.type === 'hound' && selectedPiece.nodeId === nodeId;
              const isMyTurn = currentTurn === 'hound' && isInteractive;

              return (
                <motion.g
                  key={`hound-piece-${idx}`}
                  className={`transition-opacity duration-300 ${isMyTurn ? 'cursor-pointer' : 'cursor-default'}`}
                  onClick={() => isInteractive && onSelectNode(nodeId)}
                  animate={{ x: node.cx, y: node.cy }}
                  transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                >
                  {/* Active selection glow */}
                  {isSelected && (
                    <circle
                      cx="0"
                      cy="0"
                      r="26"
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="3.5"
                      filter="url(#glowGold)"
                    />
                  )}

                  {/* Piece body */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isSelected ? '22' : '20'}
                    fill="url(#houndGrad)"
                    stroke="#ffffff"
                    strokeWidth="2.5"
                    className="shadow-md transition-all duration-200"
                  />

                  {/* Dog Emoji Icon */}
                  <text
                    x="0"
                    y="1"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="18"
                    className="pointer-events-none select-none"
                  >
                    🐕
                  </text>

                  {/* Hound index badge (1, 2, 3) */}
                  <g transform="translate(12, -12)">
                    <circle cx="0" cy="0" r="7" fill="#0f172a" stroke="#f59e0b" strokeWidth="1" />
                    <text
                      x="0"
                      y="0.5"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fill="#fef3c7"
                      fontSize="9"
                      fontWeight="bold"
                    >
                      {idx + 1}
                    </text>
                  </g>
                </motion.g>
              );
            })}

            {/* Hare */}
            {(() => {
              const node = nodePositions[hare];
              const isSelected = selectedPiece?.type === 'hare';
              const isMyTurn = currentTurn === 'hare' && isInteractive;

              return (
                <motion.g
                  key="hare-piece"
                  className={`transition-opacity duration-300 ${isMyTurn ? 'cursor-pointer' : 'cursor-default'}`}
                  onClick={() => isInteractive && onSelectNode(hare)}
                  animate={{ x: node.cx, y: node.cy }}
                  transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                >
                  {/* Active selection glow */}
                  {isSelected && (
                    <circle
                      cx="0"
                      cy="0"
                      r="26"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="3.5"
                      filter="url(#glowGreen)"
                    />
                  )}

                  {/* Piece body */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isSelected ? '22' : '20'}
                    fill="url(#hareGrad)"
                    stroke="#ffffff"
                    strokeWidth="2.5"
                    className="shadow-md transition-all duration-200"
                  />

                  {/* Rabbit Emoji Icon */}
                  <text
                    x="0"
                    y="1"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="19"
                    className="pointer-events-none select-none"
                  >
                    🐇
                  </text>
                </motion.g>
              );
            })()}
          </g>
        </svg>

        {/* Bottom Turn Hint Box */}
        <div className="mt-2 flex items-center justify-between text-xs px-2 text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span>猟犬: A〜D列からE〜K列へ追撃</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span>ウサギ: 猟犬3匹の左側へ突破すれば勝利</span>
          </div>
        </div>

      </div>
    </div>
  );
};
