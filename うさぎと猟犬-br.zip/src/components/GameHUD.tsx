import React from 'react';
import { GameMode, Difficulty, PlayerRole } from '../types/game';
import {
  RotateCcw,
  HelpCircle,
  Settings,
  Volume2,
  VolumeX,
  Lightbulb,
  Globe,
  Copy,
  LogOut,
} from 'lucide-react';

interface GameHUDProps {
  currentTurn: PlayerRole;
  turnCount: number;
  maxTurns: number;
  mode: GameMode;
  difficulty: Difficulty;
  isAiThinking: boolean;
  canUndo: boolean;
  soundEnabled: boolean;
  onlineRoomId?: string | null;
  onlinePlayerRole?: PlayerRole | null;
  onlineOpponentName?: string | null;
  isOnlineConnected?: boolean;
  onUndo: () => void;
  onRestart: () => void;
  onOpenRules: () => void;
  onOpenSettings: () => void;
  onOpenOnline: () => void;
  onLeaveOnline: () => void;
  onCopyRoomId: () => void;
  onToggleSound: () => void;
  onGetHint: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  currentTurn,
  turnCount,
  maxTurns,
  mode,
  difficulty,
  isAiThinking,
  canUndo,
  soundEnabled,
  onlineRoomId,
  onlinePlayerRole,
  onlineOpponentName,
  isOnlineConnected,
  onUndo,
  onRestart,
  onOpenRules,
  onOpenSettings,
  onOpenOnline,
  onLeaveOnline,
  onCopyRoomId,
  onToggleSound,
  onGetHint,
}) => {
  const modeLabels: Record<GameMode, string> = {
    pve_hare: 'あなた(ウサギ) vs AI(猟犬)',
    pve_hound: 'あなた(猟犬) vs AI(ウサギ)',
    pvp: '2人ローカル (Pass & Play)',
    online: `オンライン対局 (${onlineRoomId ? `部屋: ${onlineRoomId}` : ''})`,
    eve: 'AI vs AI 観戦モード',
  };

  const diffLabels: Record<Difficulty, string> = {
    easy: '入門 (Easy)',
    medium: '実戦 (Medium)',
    hard: '神AI (Master)',
  };

  // Turn progress towards maxTurns
  const progressPercent = Math.min(100, Math.round((turnCount / maxTurns) * 100));

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-4 pt-3 pb-1 space-y-2.5">
      {/* Top Navigation Bar */}
      <header className="flex items-center justify-between py-2 border-b border-slate-800">
        {/* Brand Zone */}
        <div className="flex items-center gap-2">
          <span className="text-2xl" role="img" aria-label="Rabbit and Hound">
            🐇🐕
          </span>
          <div className="flex flex-col">
            <h1 className="text-base sm:text-lg font-black text-slate-100 tracking-wide">
              ウサギと猟犬
            </h1>
            <span className="text-[10px] text-slate-400 font-medium">Hare &amp; Hounds</span>
          </div>
        </div>

        {/* Status in Center */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
          <span>{modeLabels[mode]}</span>
          {mode !== 'pvp' && mode !== 'online' && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-amber-400 font-semibold">{diffLabels[difficulty]}</span>
            </>
          )}
          {mode === 'online' && (
            <span className="flex items-center gap-1.5 bg-sky-950/60 text-sky-400 px-2 py-0.5 rounded border border-sky-800 text-[11px] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse"></span>
              {isOnlineConnected ? (onlineOpponentName ? `対戦中: ${onlineOpponentName}` : '相手待機中...') : '接続中...'}
            </span>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          {mode === 'online' ? (
            <>
              <button
                onClick={onCopyRoomId}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-700/60 rounded-lg transition"
                title="部屋番号をコピー"
              >
                <Copy size={14} />
                <span className="font-mono">{onlineRoomId}</span>
              </button>
              <button
                onClick={onLeaveOnline}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 rounded-lg transition"
                title="オンライン対局を退室"
              >
                <LogOut size={14} />
                <span className="hidden sm:inline">退室</span>
              </button>
            </>
          ) : (
            <button
              onClick={onOpenOnline}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-sky-300 bg-sky-950/40 hover:bg-sky-900/60 border border-sky-700/60 rounded-lg transition"
              title="オンライン通信対戦を開く"
            >
              <Globe size={15} />
              <span>通信対戦</span>
            </button>
          )}

          <button
            onClick={onToggleSound}
            aria-label={soundEnabled ? '消音にする' : '音声を有効化'}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
            title={soundEnabled ? '音声: オン' : '音声: オフ'}
          >
            {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>

          <button
            onClick={onOpenRules}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title="ルール解説を見る"
          >
            <HelpCircle size={16} />
            <span className="hidden sm:inline">ルール</span>
          </button>

          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title="対局設定を変更"
          >
            <Settings size={16} />
            <span className="hidden sm:inline">設定</span>
          </button>

          <button
            onClick={onRestart}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg shadow transition"
            title="盤面を初期化して再開"
          >
            <RotateCcw size={15} />
            <span>最初から</span>
          </button>
        </div>
      </header>

      {/* Main HUD Banner: Turn Indicator & Turn Counter */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Turn Status */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner transition-colors duration-300 ${
              currentTurn === 'hound'
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
            }`}
          >
            {currentTurn === 'hound' ? '🐕' : '🐇'}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">現在の手番</span>
              {isAiThinking && (
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-sky-400 animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span>
                  AI思考中...
                </span>
              )}
            </div>
            <div className="text-base sm:text-lg font-black">
              {currentTurn === 'hound' ? (
                <span className="text-amber-400">猟犬 (Hounds) の手番</span>
              ) : (
                <span className="text-emerald-400">ウサギ (Hare) の手番</span>
              )}
            </div>
            <div className="text-[11px] text-slate-400">
              {currentTurn === 'hound'
                ? '前進または上下のみ移動可能 (後退不可)'
                : '前後左右・斜めすべて自由に移動可能'}
            </div>
          </div>
        </div>

        {/* Turn Progress & Quick Tools */}
        <div className="w-full sm:w-auto flex flex-col sm:items-end gap-2 border-t sm:border-t-0 border-slate-800 pt-2 sm:pt-0">
          <div className="flex items-center justify-between sm:justify-end gap-3 text-xs">
            <span className="text-slate-400 font-medium">
              ターン数:{' '}
              <strong className="text-white font-mono tabular-nums text-sm">
                {turnCount}
              </strong>{' '}
              / {maxTurns}
            </span>
            <span className="text-[11px] text-emerald-400 font-medium bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
              {maxTurns}手でウサギ耐え勝ち
            </span>
          </div>

          {/* Progress bar towards endurance limit */}
          <div className="w-full sm:w-48 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Secondary Action Buttons */}
          <div className="flex items-center gap-2 mt-0.5">
            <button
              onClick={onGetHint}
              disabled={isAiThinking}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-amber-300 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-700/50 rounded-lg transition disabled:opacity-40"
              title="最善手をAIに聞く"
            >
              <Lightbulb size={13} />
              <span>ヒント</span>
            </button>

            <button
              onClick={onUndo}
              disabled={!canUndo || isAiThinking}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition disabled:opacity-40"
              title="直前の手を戻す"
            >
              <RotateCcw size={13} />
              <span>待った</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
