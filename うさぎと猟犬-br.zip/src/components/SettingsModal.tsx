import React from 'react';
import { X, Sliders, Volume2, VolumeX } from 'lucide-react';
import { BoardSetup, Difficulty, GameMode, GameSettings } from '../types/game';

interface SettingsModalProps {
  isOpen: boolean;
  settings: GameSettings;
  onClose: () => void;
  onSave: (newSettings: GameSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = React.useState<GameMode>(settings.mode);
  const [difficulty, setDifficulty] = React.useState<Difficulty>(settings.difficulty);
  const [boardSetup, setBoardSetup] = React.useState<BoardSetup>(settings.boardSetup);
  const [maxTurns, setMaxTurns] = React.useState<number>(settings.maxTurns);
  const [soundEnabled, setSoundEnabled] = React.useState<boolean>(settings.soundEnabled);
  const [showCoordinates, setShowCoordinates] = React.useState<boolean>(
    settings.showCoordinates
  );

  const handleApply = () => {
    onSave({
      mode,
      difficulty,
      boardSetup,
      maxTurns,
      soundEnabled,
      showCoordinates,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-3xl shadow-2xl p-4 sm:p-6 text-slate-200 space-y-4 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Sliders size={20} />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">対局設定</h2>
              <p className="text-xs text-slate-400">対戦モード・難易度・初期配置のカスタマイズ</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Settings Body */}
        <div className="space-y-4 text-xs sm:text-sm">
          {/* Mode Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">対戦モード</label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setMode('pve_hare')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  mode === 'pve_hare'
                    ? 'bg-emerald-950/40 border-emerald-500 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-sm">🐇 あなた (ウサギ)</div>
                <div className="text-[11px] text-slate-400">vs AI 猟犬</div>
              </button>

              <button
                type="button"
                onClick={() => setMode('pve_hound')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  mode === 'pve_hound'
                    ? 'bg-amber-950/40 border-amber-500 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-sm">🐕 あなた (猟犬)</div>
                <div className="text-[11px] text-slate-400">vs AI ウサギ</div>
              </button>

              <button
                type="button"
                onClick={() => setMode('pvp')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  mode === 'pvp'
                    ? 'bg-sky-950/40 border-sky-500 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-sm">👥 2人対戦 (Pass &amp; Play)</div>
                <div className="text-[11px] text-slate-400">1台の端末で交互操作</div>
              </button>

              <button
                type="button"
                onClick={() => setMode('eve')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  mode === 'eve'
                    ? 'bg-purple-950/40 border-purple-500 text-white font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="text-sm">🤖 AI vs AI 観戦</div>
                <div className="text-[11px] text-slate-400">神AI同士の定石研究</div>
              </button>
            </div>
          </div>

          {/* AI Difficulty (hidden for PvP) */}
          {mode !== 'pvp' && (
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                AI 難易度（Minimax深さ）
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['easy', 'medium', 'hard'] as Difficulty[]).map((d) => {
                  const labels = {
                    easy: { title: '入門', desc: '手加減あり' },
                    medium: { title: '実戦', desc: '適度な読み' },
                    hard: { title: '神AI (絶望)', desc: '完全理論手' },
                  };
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDifficulty(d)}
                      className={`p-2 rounded-xl border text-center transition ${
                        difficulty === d
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-xs font-black">{labels[d].title}</div>
                      <div className="text-[10px] text-slate-400">{labels[d].desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Initial Board Setup */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">初期配置パターン</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'standard', title: '公式標準', desc: '猟犬 A,B,D / 兎 K' },
                { id: 'line', title: '1列並び', desc: '猟犬 B,C,D / 兎 K' },
                { id: 'center_hare', title: '中央ウサギ', desc: '猟犬 A,B,D / 兎 F' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setBoardSetup(s.id as BoardSetup)}
                  className={`p-2 rounded-xl border text-center transition ${
                    boardSetup === s.id
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-black">{s.title}</div>
                  <div className="text-[10px] text-slate-400">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Turn Limit (Endurance Rule) */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              ウサギの耐え勝ちターン上限: <span className="text-amber-400 font-bold">{maxTurns} ターン</span>
            </label>
            <div className="flex items-center gap-2">
              {[20, 30, 40].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setMaxTurns(num)}
                  className={`flex-1 py-1.5 rounded-lg border text-xs font-bold transition ${
                    maxTurns === num
                      ? 'bg-slate-800 border-amber-400 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {num} 手{num === 30 ? ' (公式標準)' : ''}
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-300"
            >
              <span>効果音</span>
              <span className={soundEnabled ? 'text-amber-400' : 'text-slate-600'}>
                {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setShowCoordinates(!showCoordinates)}
              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-300"
            >
              <span>マス符号 (A〜K)</span>
              <span className={`text-[11px] font-bold ${showCoordinates ? 'text-amber-400' : 'text-slate-600'}`}>
                {showCoordinates ? '表示' : '非表示'}
              </span>
            </button>
          </div>
        </div>

        {/* Footer actions */}
        <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
          >
            キャンセル
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow transition"
          >
            設定を保存して新対局を開始
          </button>
        </div>
      </div>
    </div>
  );
};
