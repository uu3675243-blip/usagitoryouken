import React from 'react';
import { X, ShieldAlert, CheckCircle2, Award, BookOpen } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-3xl shadow-2xl p-4 sm:p-6 text-slate-200 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <BookOpen size={20} />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white">
                ウサギと猟犬 (Hare and Hounds) 公式ルール
              </h2>
              <p className="text-xs text-slate-400">中世北欧発祥・世界のアソビ大全51収録の完全情報非対称ゲーム</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content sections */}
        <div className="space-y-4 text-xs sm:text-sm leading-relaxed">
          {/* 1. Overview */}
          <section className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 space-y-1.5">
            <h3 className="font-bold text-amber-300 text-sm flex items-center gap-2">
              <span>1. ゲーム概要 &amp; 非対称性</span>
            </h3>
            <p className="text-slate-300 text-xs">
              2人で遊ぶ戦略ゲームです。追う<strong>「猟犬（3匹）」</strong>と逃げる<strong>「ウサギ（1匹）」</strong>に分かれ、駒の数・移動方向・勝利条件が完全に異なるのが最大の特徴です。
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <div className="font-black text-amber-400 mb-1">🐕 猟犬側 (3匹・先手)</div>
                <div className="text-slate-400 text-[11px]">
                  ・先手で行動<br />
                  ・<strong>前進（右方向）または上下</strong>のみ移動可能<br />
                  ・<strong>後退（左方向）は一切不可</strong><br />
                  ・ウサギを完全に包囲して動けなくすれば勝利
                </div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <div className="font-black text-emerald-400 mb-1">🐇 ウサギ側 (1匹・後手)</div>
                <div className="text-slate-400 text-[11px]">
                  ・後手で行動<br />
                  ・<strong>前後左右・斜め全方向</strong>に移動可能<br />
                  ・猟犬の包囲網を突破するか、<strong>30ターン耐えれば勝利</strong>
                </div>
              </div>
            </div>
          </section>

          {/* 2. Board & Movement */}
          <section className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 space-y-2">
            <h3 className="font-bold text-amber-300 text-sm">2. 盤面と駒の動き</h3>
            <div className="text-xs text-slate-300 space-y-1">
              <p>・盤面は<strong>全11個の頂点（A〜K）</strong>と、それらを結ぶ線（辺）で構成されます。</p>
              <p>・各手番では、自分の駒を<strong>線で結ばれた隣接する空きマスへ1マスだけ</strong>移動させます。</p>
              <p>・駒が既に存在するマスには重なることができません。パスは禁止です。</p>
            </div>
            <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-[11px] text-slate-400">
              <span className="font-bold text-slate-200">⚠️ 猟犬の後退禁止ルール:</span>
              <br />
              猟犬は開始位置側（左側）のマスへ戻ることはできません。常に右方向へ前進するか、同じ列の上下マスへ移動してウサギを挟み込みます。
            </div>
          </section>

          {/* 3. Victory Conditions */}
          <section className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 space-y-2">
            <h3 className="font-bold text-amber-300 text-sm">3. 勝利条件</h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2 bg-emerald-950/30 p-2.5 rounded-xl border border-emerald-900/50">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-black text-emerald-300">ウサギの勝利（いずれか達成）</div>
                  <div className="text-slate-300 text-[11px]">
                    <strong>① 突破勝利:</strong> ウサギが猟犬3匹すべての左側（後方）へすり抜けた場合。猟犬は後ろに戻れないため、追い付くことが不可能となりウサギの勝利が確定します。
                    <br />
                    <strong>② 耐え勝ち:</strong> 合計30ターン（猟犬とウサギの合計手番）が経過するまで捕まらずに生き残った場合。
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2 bg-amber-950/30 p-2.5 rounded-xl border border-amber-900/50">
                <ShieldAlert size={16} className="text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-black text-amber-300">猟犬の勝利</div>
                  <div className="text-slate-300 text-[11px]">
                    <strong>包囲勝利:</strong> ウサギの手番時に、ウサギが移動できる隣接マスがすべて塞がれ、どこにも動けなくなった（合法手ゼロ）場合。
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 4. Strategy & Math Insights */}
          <section className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 space-y-2">
            <h3 className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
              <Award size={16} />
              <span>4. 必勝理論と戦略のコツ</span>
            </h3>
            <div className="text-xs text-slate-300 space-y-1.5">
              <p>
                組合せゲーム理論の研究（Berlekamp, Conway, Guy）により、<strong>「猟犬側が最善手を指し続ければ必ず勝てる」</strong>ことが数学的に証明されています。しかし、猟犬側がわずか1手でも判断を誤ると一瞬でウサギに突破されます。
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                  <span className="font-bold text-amber-400">🐕 猟犬側のコツ:</span>
                  <ul className="list-disc list-inside text-slate-400 mt-1 space-y-0.5">
                    <li>3匹の列を揃えて「ハーフコートプレス」を作る</li>
                    <li>中央のFマス（ハブ）を効果的に抑える</li>
                    <li>1匹だけ孤立して前進しすぎない</li>
                  </ul>
                </div>
                <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                  <span className="font-bold text-emerald-400">🐇 ウサギ側のコツ:</span>
                  <ul className="list-disc list-inside text-slate-400 mt-1 space-y-0.5">
                    <li>上下の端を揺さぶり、猟犬の連携を崩す</li>
                    <li>隙間が開いた瞬間に斜めを突いて突破</li>
                    <li>無理に攻めず、左右往復で30ターン耐え抜く</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow transition"
          >
            ルールを閉じて対局へ戻る
          </button>
        </div>
      </div>
    </div>
  );
};
