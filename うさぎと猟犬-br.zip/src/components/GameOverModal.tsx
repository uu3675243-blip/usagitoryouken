import React from 'react';
import { GameStatus, PlayerRole } from '../types/game';
import { Award, RotateCcw, Eye } from 'lucide-react';

interface GameOverModalProps {
  status: GameStatus;
  turnCount: number;
  maxTurns: number;
  userRole?: PlayerRole | 'both';
  onRestart: () => void;
  onReviewBoard: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  status,
  turnCount,
  maxTurns,
  userRole,
  onRestart,
  onReviewBoard,
}) => {
  if (status === 'playing') return null;

  let title = '';
  let winner = '';
  let reason = '';
  let isUserWin = false;
  let emoji = '🏆';
  let bannerColor = 'from-amber-500/20 to-emerald-500/20 border-amber-500/40';

  if (status === 'hare_won_escape') {
    winner = 'ウサギ (Hare) の勝利！';
    title = '突破完了！逃げ切り成功';
    reason =
      'ウサギが猟犬3匹すべての後方（左側）へすり抜けました。猟犬は後ろに戻れないため、ウサギの完全逃亡が確定しました。';
    emoji = '🐇✨';
    isUserWin = userRole === 'hare';
    bannerColor = 'from-emerald-950/60 to-emerald-900/30 border-emerald-500/50';
  } else if (status === 'hare_won_timeout') {
    winner = 'ウサギ (Hare) の勝利！';
    title = '規定手数 耐え勝ち成功！';
    reason = `ウサギが猟犬の猛追をかわし、${maxTurns}ターンの間捕まることなく逃げ延びました。`;
    emoji = '⏱️🐇';
    isUserWin = userRole === 'hare';
    bannerColor = 'from-emerald-950/60 to-teal-900/30 border-emerald-500/50';
  } else if (status === 'hound_won_trapped') {
    winner = '猟犬 (Hounds) の勝利！';
    title = '完全包囲！ウサギ捕獲';
    reason =
      '猟犬のチームワークにより、ウサギの動ける隣接マスがすべて塞がれました（合法手ゼロ）。';
    emoji = '🐕🎯';
    isUserWin = userRole === 'hound';
    bannerColor = 'from-amber-950/60 to-orange-900/30 border-amber-500/50';
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div
        className={`w-full max-w-md rounded-3xl bg-slate-900 border ${bannerColor} shadow-2xl p-6 text-center space-y-4`}
      >
        {/* Animated Celebration Icon */}
        <div className="text-5xl animate-bounce pt-2">{emoji}</div>

        <div>
          <span className="text-xs font-bold tracking-widest text-slate-400">
            {isUserWin
              ? '🎉 CONGRATULATIONS! あなたの勝利！'
              : userRole === 'both'
              ? 'GAME OVER 対局終了'
              : 'MATCH RESULT'}
          </span>
          <h2 className="text-2xl font-black text-white mt-1">{winner}</h2>
          <div className="text-amber-400 font-bold text-sm mt-0.5">{title}</div>
        </div>

        {/* Reason Card */}
        <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 text-xs text-slate-300 leading-relaxed text-left">
          <p>{reason}</p>
          <div className="mt-2 pt-2 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
            <span>総手数: <strong className="text-white font-mono">{turnCount}</strong> 手</span>
            <span>耐え勝ち基準: {maxTurns} 手</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={onReviewBoard}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition"
          >
            <Eye size={15} />
            <span>盤面を確認</span>
          </button>

          <button
            onClick={onRestart}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-lg transition"
          >
            <RotateCcw size={15} />
            <span>もう一度遊ぶ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
